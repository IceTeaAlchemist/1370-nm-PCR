//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  GaussNewton4.h
//
//  Code generation for function 'GaussNewton4'
//


#ifndef GAUSSNEWTON4_H
#define GAUSSNEWTON4_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void GaussNewton4(const coder::array<double, 2U> &x, const coder::array<
  double, 2U> &y, const double beta0[4], double coeff[4], double *iter);

#endif

// End of code generation (GaussNewton4.h)
