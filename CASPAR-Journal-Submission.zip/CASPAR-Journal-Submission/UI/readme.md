This folder contains the HTML/JS UI for the CASPAR instrument.
