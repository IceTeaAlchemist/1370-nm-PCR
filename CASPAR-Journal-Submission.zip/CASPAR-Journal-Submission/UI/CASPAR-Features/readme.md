Features in the CASPAR UI that were implemented
