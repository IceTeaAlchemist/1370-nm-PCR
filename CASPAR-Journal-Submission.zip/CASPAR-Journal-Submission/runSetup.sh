#!/usr/bin/env bash
# To run
# chmod +x ./runSetup.sh
# ./runSetup.sh
# 20220711 weg, started with Nick.
# 20221005 weg, comment edits.

# Function that echoes the command to the terminal.
domod () {
        echo "$@"
        $@
}

# Check if node (with npm) were installed.  Is in the systemSetup.sh also.
which node
if [ $? != 0 ]; then
    # These "sudo"s below did not quit do it once.  Added -E, stop if any command fails.
    domod sudo curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
    domod sudo apt-get install -y nodejs
    echo
    echo "node version `node -v`"
    echo
fi

echo "npm init"
npm init<<EOF
caspar
0.0.1


ISC
yes
EOF

domod npm install ws
domod npm install nodemailer
domod npm install fs
domod npm install http

# Test that node-gyp is installed.  Which returns 0 if it finds it, 1 if not.
which node-gyp
if [ $? != 0 ]; then
    domod sudo npm install -g node-gyp
fi

# node-gyp rebuild includes clean, configure, then build.
# node-gyp configure
domod node-gyp rebuild

# Fix that the script is being run as sudo for the build dir.
domod sudo chown -R pi.pi build

domod mkdir -p data/serverlog
domod mkdir -p configs
domod touch ./configs/configs.txt

# domod sudo cp -i ./UI/CASPAR-UI.html /var/www/html/
domod sudo ln -s ${PWD}/UI/CASPAR-UI.html /var/www/html/
domod sudo ln -s ${PWD}/icons/favicon.ico /var/www/html/
domod sudo ln -s ${PWD}/data /var/www/html/
domod sudo ln -s ${PWD} /var/www/html/

echo "sudo cp -fpr ./\"JS Libraries/src\" /var/www/html/"
sudo cp -fpr ./"JS Libraries/src" /var/www/html/

# Copy over the startSever script and the Desktop icon.
domod cp -p ./icons/startServer.sh ~/bin
domod cp -p ./icons/ghost-icon-12496.png ~/bin
domod cp -p ./icons/CASPAR.desktop ~/Desktop

# Link the correct devices<Machine name>.ini file to devices.ini .
echo "For linking the correct devices.ini file,"
echo "what is the machine name? Type 10 for Production01, 11 for Production02,"
echo "12 for CASPAR01, and 13 for CASPAR02."

read devNumber
case $devNumber in
    "10")
	devFilename="devicesProduction01.ini"
	;;
    "11")
	devFilename="devicesProduction02.ini"
	;;
    "12")
	devFilename="devicesCASPAR01.ini"
	;;
    "13")
	devFilename="devicesCASPAR02.ini"
	;;
esac

echo "You typed $devNumber for devices filename $devFilename."
echo "Will run the link command..."
echo "(cd configs; ln -sf $devFilename devices.ini)"

(cd configs; ln -sf $devFilename devices.ini)

