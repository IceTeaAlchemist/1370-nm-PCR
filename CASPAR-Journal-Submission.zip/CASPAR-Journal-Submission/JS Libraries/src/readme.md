Put these files in /var/www/html/src. They provide the libraries javascript needs to import for the webpage.
